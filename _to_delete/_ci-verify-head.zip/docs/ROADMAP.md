# Roadmap

Work is cut into **phases** (a playable milestone each) and **work packages** (WPs: one agent, one branch, one PR, hours to a couple of days). Each WP file in `docs/roadmap/phase-N/` states goal, owned folders, interfaces, acceptance criteria and a playtest checklist. Within a phase, WPs in the same *lane* are independent and can run in parallel; arrows are hard dependencies.

```mermaid
flowchart LR
    P0[Phase 0<br/>Foundation ✅] --> P1[Phase 1<br/>Playable single-player loop ✅]
    P1 --> P2[Phase 2<br/>Island, art & content ✅]
    P1 --> P3[Phase 3<br/>Progression & abilities]
    P1 --> P4[Phase 4<br/>Multiplayer]
    P2 & P3 & P4 --> P5[Phase 5<br/>Polish & release to friends]
    P5 --> P6[Phase 6<br/>Stretch]
```

Phases 2, 3 and 4 are deliberately independent so three streams can run at once after phase 1.

## Phase 0 — Foundation ✅ (this repo)

Bootable gray-box vertical slice; pure core with 74 tests; data-driven content; i18n; CI (tests → web export → Pages); docs, ADRs, agent guide.

**Remaining human steps:** push to GitHub, enable Pages (Settings → Pages → Source: GitHub Actions), open the project in Godot 4.7 once and press F5, walk to a can, press E, walk to the pant bag, press E.

## Phase 1 — Playable single-player loop

*Exit criterion: a friend can play Island 01 start to finish in a browser, see their grade, and want to try again.*

**Status: everything except WP-1.7 (controller feel) is done — 190 tests.** The loop is complete end to end: title → play → evaluation → restart, with autosave and resume.

| WP | Title | Lane | Owns | Depends on |
|---|---|---|---|---|
| [1.1](roadmap/phase-1/WP-1.1-carry-visuals.md) ✅ | Carried items visible in hand | items | `src/game/items/` | — |
| [1.2](roadmap/phase-1/WP-1.2-placement-feedback.md) ✅ | Placement feedback: flash, chime, completion glow | containers+audio | `src/game/containers/`, `assets/audio/sfx/` | — |
| [1.3](roadmap/phase-1/WP-1.3-take-out-and-slot-targeting.md) ✅ | Take items back out; aim at a specific slot | containers/player | `src/game/containers/`, `src/game/player/` | 1.2 |
| [1.4](roadmap/phase-1/WP-1.4-hud-v1.md) ✅ | HUD v1 (Danish): progress, carrying, prompts, toasts | hud | `src/game/hud/` | — |
| [1.5](roadmap/phase-1/WP-1.5-evaluation-screen.md) ✅ | End-of-level evaluation screen + restart | hud/flow | `src/game/hud/evaluation/`, `src/game/main/` | 1.4 |
| [1.6](roadmap/phase-1/WP-1.6-title-and-flow.md) ✅ | Title screen, seed entry, pause, restart | flow | `src/game/main/`, `src/game/title/` | — |
| [1.7](roadmap/phase-1/WP-1.7-controller-feel.md) | Controller feel: acceleration, head bob toggle, FOV, sensitivity | player | `src/game/player/` | — |
| [1.8](roadmap/phase-1/WP-1.8-save-load.md) ✅ | Save/load via WorldState snapshot (core + autoload) | core/infra | `src/core/save_game.gd`, `src/autoload/` | — |

Parallel-safe sets: {1.1, 1.2, 1.4, 1.6, 1.7, 1.8} can all start at once. 1.3 after 1.2; 1.5 after 1.4.

## Phase 2 — Island, art & content

*Exit criterion: the island looks like a place; 150+ items; it still loads in < 10 s on a normal connection.*

**Phase 2 is complete — 279 tests, 162 items, 14 containers, 12.5 MB gzipped download.** Every container and most item categories have real models (ADR 0009); trash, food, cookware, clothing and misc are still generated boxes and the game is fully playable that way. Assets that are not models are generated in code (ADR 0008).

Exit criterion — "the island looks like a place; 150+ items; loads in < 10 s on a normal connection" — is met on home broadband (~4 s) and not on mobile data (~21 s), three quarters of it the Godot engine wasm. The one thing phase 2 could not check from CI is frame rate on real hardware; see WP-2.8.

| WP | Title | Owns |
|---|---|---|
| [2.1](roadmap/phase-2/WP-2.1-terrain.md) ✅ | Procedural island terrain replacing the gray-box cylinder | `src/game/island/` |
| [2.2](roadmap/phase-2/WP-2.2-item-models.md) ✅ | Item model kit: loader + hand-sourced `.glb` models via `ItemDef.model`; fallback box stays | `assets/models/items/`, `src/game/items/` |
| [2.3](roadmap/phase-2/WP-2.3-container-models.md) ✅ | Container models: 13 of 14 in, fitted by real-world height, slots as a tray above them | `assets/models/containers/`, `src/game/containers/` |
| [2.4](roadmap/phase-2/WP-2.4-content.md) ✅ | Content: 162 items, 14 containers, two canoes with crews, sleeping bags ordered, unopened beer in two coolers | `data/`, `assets/i18n/` |
| [2.5](roadmap/phase-2/WP-2.5-environment.md) ✅ | Environment: trees, grass, reeds, bigger water (sky/water shaders and wind still open) | `src/game/island/environment/` |
| [2.6](roadmap/phase-2/WP-2.6-audio.md) ✅ | Audio: ambient lake, birds, music layers that rise with completion | `src/game/audio/`, `assets/audio/` |
| [2.7](roadmap/phase-2/WP-2.7-mess-dressing.md) ✅ | Mess dressing: collapsed tent, a mate still asleep and snoring, trampled ground — no colliders | `src/game/island/dressing/` |
| [2.8](roadmap/phase-2/WP-2.8-web-performance.md) ✅ | Web performance: download measured and budgeted in CI (12.5 MB gzipped), scene-shape budgets | `tools/`, `tests/` |

**Models are sourced by hand** (ADR 0009): `.glb` only, CC0 or CC-BY only, and every file needs a row in `assets/models/CREDITS.md` before it ships. One model serves a whole category, rotated differently per item. Five categories are still boxes: `trash`, `food`, `cookware`, `clothing`, `misc` — filling them in is a data change, not a code change.

**Sizes are stated in metres, not derived from gameplay numbers.** `ItemPalette.CATEGORY_LENGTHS` for items, `ContainerDef.model_height` for containers. Deriving metres from carry slots made a paddle 34 cm long and a bin bag 5.3 m tall.

## Phase 3 — Progression & abilities

*Exit criterion: completing containers feels rewarding; every ability is usable and tested.*

| WP | Title | Owns |
|---|---|---|
| 3.1 | Skill point UI + unlock menu (Tab) | `src/game/hud/skills/` |
| 3.2 | Klarsyn (Insight): series siblings glow | `src/game/abilities/insight/` |
| 3.3 | Stedsans (Map sense): HUD arrow | `src/game/abilities/map_sense/` |
| 3.4 | Råb på en kammerat (Call a mate): items fly to you — needs a core `summon` command | `src/core/` (new command), `src/game/abilities/call_mate/` |
| 3.5 | Rolige hænder: capacity bonus applied live | `src/autoload/` (capacity refresh), tests |
| 3.6 | Autopilot: proximity auto-place | `src/game/abilities/auto_place/` |
| 3.7 | Hidden collectibles (4 per island) | `data/`, `src/game/collectibles/` |
| 3.8 | Evaluation tuning: par times from playtests, grade copy | `data/levels/`, `assets/i18n/` |
| 3.9 | **Hvalen** — timed beer-bong call (see below) | `src/core/` (new command + consumed state), `src/game/events/` |

3.1 first (others plug into it); 3.4 and 3.9 both need core changes → do those first in the core lane.

### WP-3.9 — Hvalen (captured, not yet designed)

KA's idea, noted as-is: **a sound plays; the crew then has ~30 s to find "Hvalen" (a beer bong) which spawns somewhere random on the island, plus an unopened beer. A player holding both before the timer runs out drinks a beer bong.** Reward: possibly a skill unlock. Failure: a random container empties back out onto the island.

Worth thinking about before this gets written up properly:

- **The penalty is the first mechanic that can undo work.** The pant bag holds 34 items; dumping it could erase ten minutes. Scaling it — the smallest packed container, or N items rather than a whole one — is probably the difference between tension and a rage quit.
- **30 s for something you have never seen** is tight on a 32 m island at 4.5 m/s. Either the Hvalen announces itself (glow, sound), or the window is longer, or both.
- **The beer has to come from somewhere.** All twelve unopened beers live in the two coolers. Late in a run, answering the call means taking one back out and un-completing a cooler — an interesting trade, or an annoying one. Worth deciding deliberately rather than discovering.
- **Drinking removes an item from the world**, which breaks "the island is clean when every item is placed". Cleanest fix is a `CONSUMED` state in `WorldState` that counts as cleared; the alternative (the empty can it leaves behind becomes a new item to tidy) is more fun and more work.
- **It must be deterministic and go through a command**, like everything else in `src/core/` — the call time and the Hvalen's spawn come from the seed, or six browsers will disagree about whether anyone made it.
- **Frequency:** two or three calls in a 20-minute run, never in the first few minutes, never in the last.

## Phase 4 — Multiplayer (≤ 6, host-authoritative WebRTC)

*Exit criterion: six browsers on different networks finish Island 01 together via a room code.*

| WP | Title | Owns |
|---|---|---|
| 4.1 | Signalling service (Cloudflare Worker) + protocol doc | `infra/signalling/`, `docs/NETWORKING.md` |
| 4.2 | `WebRtcTransport`: command relay, event broadcast, snapshot on join, ordering guarantees | `src/net/` |
| 4.3 | Simulated multi-peer test harness (N processors, one authority, in-process) | `tests/net/`, `src/net/sim_transport.gd` |
| 4.4 | Lobby: create/join by room code, player list, ready-up, seed sync | `src/game/lobby/` |
| 4.5 | Remote player avatars: `MultiplayerSynchronizer` transforms, name tags, held items | `src/game/player/remote/` |
| 4.6 | Join/leave/reconnect, host-left handling, dropped items on disconnect | `src/net/`, `src/autoload/` |
| 4.7 | Multiplayer HUD: who placed what, shared toasts, ping | `src/game/hud/` |

Order: 4.3 (harness) and 4.1 first and in parallel; 4.2 uses 4.3; 4.4/4.5/4.7 after 4.2.

## Phase 5 — Polish & release to friends

Settings (sensitivity, FOV, language toggle, audio), accessibility (colour-blind-safe verdict colours, subtitles for cues), hangover-blur intro shader, itch.io mirror, PWA icon, README screenshots, first playtest with the actual canoe crew and a bug-fix week.

## Phase 6 — Stretch

Second island (different lake, night arrival), weather events (rain scatters items again), host migration, speedrun timer + local leaderboard, gamepad support, mobile touch layout.

## How WPs get written

Copy `docs/roadmap/WP-TEMPLATE.md`. Keep it under a page. If a WP would touch more than two owned folders, split it.
